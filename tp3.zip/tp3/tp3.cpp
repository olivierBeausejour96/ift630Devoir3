/******************************************************
TP3

STUDENTS:

AUTHORS: Pierre-Marc Jodoin, Louis-Philippe Ledoux
Richard Egli (modifications au vertex shader)

DATE : Winter 2016
*******************************************************/

#define GLUT_DISABLE_ATEXIT_HACK

#define NDEBUG

#include <windows.h>
#include <gl/glew.h>
#include <gl/freeglut.h>
#include <GL/gl.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <vector>

#include <iostream>
#include <fstream>
#include <sstream>

#include <math.h>

//GLM Includes
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"
#include "structures.h"

using namespace std;


/******************************\
*****   Global variables   *****
\******************************/
MouseEvent	lastMouseEvt;			/* Last mouse event */
CamInfo		gCam;	                /* Camera parameters */

Material	materials[2];	        /* 0 = plane, 1 = revolution object */
Light		lights[2]; 				/* 0 = white, 1 = blue */
Light*		currentLight = lights;/* Current light, the one selected with the mouse middle button */

// Silhouette parameters : the silhouette contains 4 2D points 
#define		NB_PTS_ON_SILHOUETTE 17
glm::vec2	silhouettePointArray[NB_PTS_ON_SILHOUETTE];
int 		objectResolution = 7;	/* the number of times the silhouette is rotated. */

// On/off binary variables
bool		displayNormals = false;
bool		displayRevolutionObject = false;
bool        isLightEnabled = true;	/* Lighting is disabled when = false */

// Array and buffer Objects. vao:vertex array object, vbo: vertex buffer object, nbo: normal buffer object
unsigned int vaoPlaneID; 
unsigned int vboPlaneID;
unsigned int nboPlaneID;

unsigned int vaoRevolutionID;
unsigned int vboRevolutionID;
unsigned int nboRevolutionID;

unsigned int vaoLightID;
unsigned int vboLightID;

unsigned int vaoNormalsID;
unsigned int vboNormalsID;

// Camera matrices
glm::mat4	projectionMatrix; 
glm::mat4	viewMatrix; 

// Shader
Shader*		shader;

/**********************\
***** Prototypes *****
\**********************/
// function for creating vertices, copying it on the GPU and drawing objects
void updatePlaneMesh();
void updateRevolutionObjectMesh();
void updateNormalLines();

void drawPlane();
void drawRevolutionObject();
void drawLight(int idx);
std::vector<glm::vec3> getSphereVertices(float radius, int slices, int stacks);

// Initialization functions
void initObjects();
void initGPUBuffers(void);
void initLights();
void initMaterials();

void setCameraMatrices();

/* Callbacks */
void keyboard(unsigned char key, int x, int y);
void mouseButton(int button, int state, int x, int y);
void mouseMove(int x, int y);
void display(void);


/*****************************************************
NAME: deg2rad and rad2deg

DESCRIPTION: Switche degrees to radians, and the opposite

*****************************************************/
float deg2rad(float deg)
{
    return	0.01745329251994329547437168059786927187815f * deg;
}

float rad2deg(float rad)
{
    return	57.2957795130823228646477218717336654663085f * rad;
}

/*****************************************************
NAME: initMaterials

DESCRIPTION: initialize material parameters.
*****************************************************/
void initMaterials()
{
	/* Gold Plane */
	materials[0].ambient[0] = 0.33f; materials[0].ambient[1] = 0.22f; materials[0].ambient[2] = 0.03f; materials[0].ambient[3] = 1.0f;
	materials[0].diffuse[0] = 0.7f; materials[0].diffuse[1] = 0.5f; materials[0].diffuse[2] = 0.1f; materials[0].diffuse[3] = 1.0f;
	materials[0].specular[0] = 1.0f; materials[0].specular[1] = 1.0f; materials[0].specular[2] = 1.0f; materials[0].specular[3] = 1.0f;
	materials[0].shininess = 127.0f;

	/* Red Revolution object */
	materials[1].ambient[0] = 0.5f; materials[1].ambient[1] = 0.1f; materials[1].ambient[2] = 0.0f; materials[1].ambient[3] = 1.0f;
	materials[1].diffuse[0] = 1.0f; materials[1].diffuse[1] = 0.2f; materials[1].diffuse[2] = 0.0f; materials[1].diffuse[3] = 1.0f;
	materials[1].specular[0] = 0.5f; materials[1].specular[1] = 0.3f; materials[1].specular[2] = 0.0f; materials[1].specular[3] = 1.0f;
	materials[1].shininess = 3.0f;
}

/*****************************************************
NAME: initObjects

DESCRIPTION: initialize the objects, and the silhouette for the revolution object.
	This means creating the GPU vertex arrays and vertex buffers.  

	For the lights, since their mesh is constant, we shall also create its
	vertices and copy it in the GPU.
*****************************************************/
void initObjects()
{
	silhouettePointArray[0].x = 2.0f;	silhouettePointArray[0].y = -100.0f;
	silhouettePointArray[1].x = 43.0f;	silhouettePointArray[1].y = -100.0f;
	silhouettePointArray[2].x = 86.0f;	silhouettePointArray[2].y = -100.0f;
	silhouettePointArray[3].x = 61.0f;	silhouettePointArray[3].y = -91.0f;
	silhouettePointArray[4].x = 40.0f;	silhouettePointArray[4].y = -88.0f;
	silhouettePointArray[5].x = 17.0f;	silhouettePointArray[5].y = -83.0f;
	silhouettePointArray[6].x = 25.0f;	silhouettePointArray[6].y = -54.0f;
	silhouettePointArray[7].x = 24.0f;	silhouettePointArray[7].y = -30.0f;
	silhouettePointArray[8].x = 22.0f;	silhouettePointArray[8].y = -5.0f;
	silhouettePointArray[9].x = 14.0f;	silhouettePointArray[9].y = 21.0f;
	silhouettePointArray[10].x = 11.0f;	silhouettePointArray[10].y = 54.0f;
	silhouettePointArray[11].x = 25.0f;	silhouettePointArray[11].y = 60.0f;
	silhouettePointArray[12].x = 40.0f;	silhouettePointArray[12].y = 65.0f;
	silhouettePointArray[13].x = 54.0f;	silhouettePointArray[13].y = 67.0f;
	silhouettePointArray[14].x = 70.0f;	silhouettePointArray[14].y = 75.0f;
	silhouettePointArray[15].x = 80.0f;	silhouettePointArray[15].y = 84.0f;
	silhouettePointArray[16].x = 85.0f;	silhouettePointArray[16].y = 95.0f;

	initGPUBuffers();
	initLights();
}

/*****************************************************
NAME: initGPUBuffers

DESCRIPTION: Create the vertex array object and buffer object for each 3D object
*****************************************************/
void initGPUBuffers(void)
{
	// Sphere for the 3D lights
	glGenVertexArrays(1, &vaoLightID);
	glGenBuffers(1, &vboLightID);

	//Revolution objects
	glGenVertexArrays(1, &vaoRevolutionID);
	glGenBuffers(1, &vboRevolutionID);
	glGenBuffers(1, &nboRevolutionID);

	//Plane
	glGenVertexArrays(1, &vaoPlaneID);
	glGenBuffers(1, &vboPlaneID);
	glGenBuffers(1, &nboPlaneID);

	//Normals
	glLineWidth(1.0f);

	glGenVertexArrays(1, &vaoNormalsID);
	glGenBuffers(1, &vboNormalsID);

}

/*****************************************************
NAME: initLights

DESCRIPTION: This function does 3 things :

1- Set the light properties
2- create the vertices of a sphere
3- copy the vertices on the GPU
*****************************************************/
void initLights()
{
	/*
	**	Set Light properties
	*/
	lights[0].ambient[0] = 0.7f; lights[0].ambient[1] = 0.7f; lights[0].ambient[2] = 0.7f; lights[0].ambient[3] = 1.0f;
	lights[0].diffuse[0] = 0.7f; lights[0].diffuse[1] = 0.7f; lights[0].diffuse[2] = 0.7f; lights[0].diffuse[3] = 1.0f;
	lights[0].specular[0] = 0.7f; lights[0].specular[1] = 0.7f; lights[0].specular[2] = 0.7f; lights[0].specular[3] = 1.0f;
	lights[0].position[0] = 70.0f; lights[0].position[1] = -70.0f; lights[0].position[2] = 70.0f; lights[0].position[3] = 1.0f;

	lights[0].Kc = 0.0f;
	lights[0].Kl = 0.01f;
	lights[0].Kq = 0.0f;
	lights[0].on = true;

	lights[1].ambient[0] = 0.0f; lights[1].ambient[1] = 0.0f; lights[1].ambient[2] = 1.0f; lights[1].ambient[3] = 1.0f;
	lights[1].diffuse[0] = 0.0f; lights[1].diffuse[1] = 0.0f; lights[1].diffuse[2] = 1.0f; lights[1].diffuse[3] = 1.0f;
	lights[1].specular[0] = 0.0f; lights[1].specular[1] = 0.0f; lights[1].specular[2] = 1.0f; lights[1].specular[3] = 1.0f;
	lights[1].position[0] = -10.0f; lights[1].position[1] = -90.0f; lights[1].position[2] = -10.0f; lights[1].position[3] = 1.0f;

	lights[1].Kc = 1.0f;
	lights[1].Kl = 0.0f;
	lights[1].Kq = 0.0f;
	lights[1].on = true;

	/*
	**	Create light vertices : 3D sphere
	*/
	std::vector<glm::vec3> vertices = getSphereVertices(5, 10, 10);

	/*
	**	Copy vertices of the light objects on the GPU
	*/
	glBindVertexArray(vaoLightID); // Bind our Vertex Array Object so we can use it  

	glBindBuffer(GL_ARRAY_BUFFER, vboLightID); // Bind our Vertex Buffer Object 
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), &vertices[0], GL_STATIC_DRAW); // Set the size and data of our VBO and set it to STATIC_DRAW 

	int in_PositionLocation = glGetAttribLocation(shader->id(), "in_Position");
	glEnableVertexAttribArray(in_PositionLocation);
	glVertexAttribPointer(in_PositionLocation, 3, GL_FLOAT, GL_FALSE, 0, 0); // Set up our vertex attributes pointer
}

/*****************************************************
NAME: copyLightParametersOnGPU

DESCRIPTION: copy the parameters of both lights on the GPU
*****************************************************/
void copyLightParametersOnGPU(void)
{
	shader->bind(); // Bind shader

	int lightPosLocation = glGetUniformLocation(shader->id(), "lightPosition");
	int lightLaLocation = glGetUniformLocation(shader->id(), "lightLa");
	int lightLdLocation = glGetUniformLocation(shader->id(), "lightLd");
	int lightLsLocation = glGetUniformLocation(shader->id(), "lightLs");
	int lightKcLocation = glGetUniformLocation(shader->id(), "lightKc");
	int lightKlLocation = glGetUniformLocation(shader->id(), "lightKl");
	int lightKqLocation = glGetUniformLocation(shader->id(), "lightKq");

	int lightPosLocation2 = glGetUniformLocation(shader->id(), "lightPosition2");
	int lightLaLocation2 = glGetUniformLocation(shader->id(), "lightLa2");
	int lightLdLocation2 = glGetUniformLocation(shader->id(), "lightLd2");
	int lightLsLocation2 = glGetUniformLocation(shader->id(), "lightLs2");
	int lightKcLocation2 = glGetUniformLocation(shader->id(), "lightKc2");
	int lightKlLocation2 = glGetUniformLocation(shader->id(), "lightKl2");
	int lightKqLocation2 = glGetUniformLocation(shader->id(), "lightKq2");

	glUniform4f(lightPosLocation, lights[0].position[0], lights[0].position[1], lights[0].position[2], isLightEnabled ? 1.f : 0.f);
	glUniform3f(lightLaLocation, lights[0].ambient[0], lights[0].ambient[1], lights[0].ambient[2]);
	glUniform3f(lightLdLocation, lights[0].diffuse[0], lights[0].diffuse[1], lights[0].diffuse[2]);
	glUniform3f(lightLsLocation, lights[0].specular[0], lights[0].specular[1], lights[0].specular[2]);
	glUniform1f(lightKcLocation, lights[0].Kc);
	glUniform1f(lightKlLocation, lights[0].Kl);
	glUniform1f(lightKqLocation, lights[0].Kq);

	glUniform4f(lightPosLocation2, lights[1].position[0], lights[1].position[1], lights[1].position[2], isLightEnabled ? 1.f : 0.f);
	glUniform3f(lightLaLocation2, lights[1].ambient[0], lights[1].ambient[1], lights[1].ambient[2]);
	glUniform3f(lightLdLocation2, lights[1].diffuse[0], lights[1].diffuse[1], lights[1].diffuse[2]);
	glUniform3f(lightLsLocation2, lights[1].specular[0], lights[1].specular[1], lights[1].specular[2]);
	glUniform1f(lightKcLocation2, lights[1].Kc);
	glUniform1f(lightKlLocation2, lights[1].Kl);
	glUniform1f(lightKqLocation2, lights[1].Kq);

	shader->unbind(); // Bind shader
}


/*****************************************************
NAME: updateNormalLines

DESCRIPTION: create a series of lines each made of 2 vertices.
	then copy it on the GPU.  These lines are used to 
	illustrate the normals at each vertex of the revolution 
	object.
*****************************************************/
void updateNormalLines()
{
    // AJOUTER CODE ICI
}



/*****************************************************
NAME: drawNormals

DESCRIPTION: draw the normal at each vertex of the revolution object.
Somewhat similar to "drawLight"

*****************************************************/
void drawNormals()
{
   //AJOUTER CODE ICI
}



/*****************************************************
NAME: updatePlaneMesh

DESCRIPTION: create plane vertices and copy it on the GPU.   The number
of vertices on the plane is defined by the global variable "objectResolution".
The plane spans from -100 to 100 along the X and Z axis and is located
at Y=-100;

*****************************************************/
void updatePlaneMesh()
{
    float step;
    std::vector<glm::vec3> vertices;
    std::vector<glm::vec3> normals;
	glm::vec3 vertex;
	glm::vec3 normal;

	// AJOUTER CODE ICI
	// REMPLACER LE CODE DES 2 TRIANGLES POUR FORMER UN PLAN DONT
	// LA RESOLUTION DEPEND DE LA VARIABLE GLOBALE "objectResolution"
	// ==> TOUCHES 'A' ET 'a' DU CLAVIER.

	// First triangle
	normal.x = 0.f; normal.y = 1.f; normal.z = 0.f;
	vertex.x = 100.f; vertex.y = -100.f; vertex.z = 100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);

	vertex.x = 100.f; vertex.y = -100.f; vertex.z = -100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);

	vertex.x = -100.f; vertex.y = -100.f; vertex.z = 100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);

	// Second triangle
	vertex.x = 100.f; vertex.y = -100.f; vertex.z = -100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);

	vertex.x = -100.f; vertex.y = -100.f; vertex.z = -100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);

	vertex.x = -100.f; vertex.y = -100.f; vertex.z = 100.f;
	vertices.push_back(vertex);
	normals.push_back(normal);


    glBindVertexArray(vaoPlaneID);

    glBindBuffer(GL_ARRAY_BUFFER, vboPlaneID); 
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), &vertices[0], GL_STATIC_DRAW);

    int in_PositionLocation = glGetAttribLocation(shader->id(), "in_Position");
    glEnableVertexAttribArray(in_PositionLocation);
    glVertexAttribPointer(in_PositionLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, nboPlaneID);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(glm::vec3), &normals[0], GL_STATIC_DRAW);

    int in_NormalLocation = glGetAttribLocation(shader->id(), "in_Normal");
    glEnableVertexAttribArray(in_NormalLocation);
    glVertexAttribPointer(in_NormalLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);
}


/*****************************************************
NAME: drawPlane

DESCRIPTION: draw the plane

*****************************************************/
void drawPlane()
{
	shader->bind(); // bind shader

	glm::mat4 planeMatrix = glm::mat4(1.0f);

    // Get the locations of uniforms
    int projectionMatrixLocation = glGetUniformLocation(shader->id(), "projectionMatrix");
    int viewMatrixLocation = glGetUniformLocation(shader->id(), "viewMatrix");
    int modelMatrixLocation = glGetUniformLocation(shader->id(), "modelMatrix");

    int materialKaLocation = glGetUniformLocation(shader->id(), "materialKa");
    int materialKdLocation = glGetUniformLocation(shader->id(), "materialKd");
    int materialKsLocation = glGetUniformLocation(shader->id(), "materialKs");
    int materialShininessLocation = glGetUniformLocation(shader->id(), "materialShininess");

    // Copy data to the GPU
    glUniformMatrix4fv(projectionMatrixLocation, 1, GL_FALSE, &projectionMatrix[0][0]);
    glUniformMatrix4fv(viewMatrixLocation, 1, GL_FALSE, &viewMatrix[0][0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &planeMatrix[0][0]);

    glUniform3f(materialKaLocation, materials[0].ambient[0], materials[0].ambient[1], materials[0].ambient[2]);
    glUniform3f(materialKdLocation, materials[0].diffuse[0], materials[0].diffuse[1], materials[0].diffuse[2]);
    glUniform3f(materialKsLocation, materials[0].specular[0], materials[0].specular[1], materials[0].specular[2]);
    glUniform1f(materialShininessLocation, materials[0].shininess);

    // Draw our object
    glBindVertexArray(vaoPlaneID);

    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, vboPlaneID);
    glVertexAttribPointer((GLuint)0, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glEnableVertexAttribArray(1);
    glBindBuffer(GL_ARRAY_BUFFER, nboPlaneID);
    glVertexAttribPointer((GLuint)1, 3, GL_FLOAT, GL_FALSE, 0, 0);

    glDrawArrays(GL_TRIANGLES, 0, objectResolution * objectResolution * 6);

    glBindVertexArray(0);

    shader->unbind(); // Unbind shader
}



/*****************************************************
NAME: updateRevolutionObject

DESCRIPTION: create the vertices and the normals of the revolutionObject and 
copy it on the GPU (1 normal per vertex).  The number of slices (or meridan) on the 
revolution object is defined by the global variable "objectResolution"

*****************************************************/
void updateRevolutionObjectMesh()
{
    
    //AJOUTER CODE ICI
    
}

/*****************************************************
NAME: drawRevolutionObject

DESCRIPTION: draw the revolution object with material materials[1]

*****************************************************/
void drawRevolutionObject()
{
   // AJOUTER CODE ICI
}


/*****************************************************
NAME: drawLight

DESCRIPTION: draw a light specified by 'lightindex'.  Lightindex is 0 or 1.
The light is NOT shaded and its RGB color is the one stored in 
"lights[lightindex].diffuse"

*****************************************************/
void drawLight(int lightindex)
{
    shader->bind(); // Bind shader

	glm::mat4 lightModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(lights[lightindex].position[0], lights[lightindex].position[1], lights[lightindex].position[2]));

    // Get the locations of uniform variables
    int projectionMatrixLocation = glGetUniformLocation(shader->id(), "projectionMatrix");
    int viewMatrixLocation = glGetUniformLocation(shader->id(), "viewMatrix");
    int modelMatrixLocation = glGetUniformLocation(shader->id(), "modelMatrix");
    int lightPosLocation = glGetUniformLocation(shader->id(), "lightPosition");
    int materialKdLocation = glGetUniformLocation(shader->id(), "materialKd");

    // Copy data to the GPU
    glUniformMatrix4fv(projectionMatrixLocation, 1, GL_FALSE, &projectionMatrix[0][0]);
    glUniformMatrix4fv(viewMatrixLocation, 1, GL_FALSE, &viewMatrix[0][0]);
    glUniformMatrix4fv(modelMatrixLocation, 1, GL_FALSE, &lightModelMatrix[0][0]);
    glUniform4f(lightPosLocation, 0.f, 0.f, 0.f, 0.f);
    glUniform3f(materialKdLocation, lights[lightindex].diffuse[0], lights[lightindex].diffuse[1], lights[lightindex].diffuse[2]);

    // Draw object
    glBindVertexArray(vaoLightID);

    glDrawArrays(GL_TRIANGLES, 0, 10 * 10 * 6);

    glBindVertexArray(0);

    shader->unbind(); // Unbind shader
}



/*****************************************************
NAME: getSphereVertices

DESCRIPTION: get the vertices of a sphere made of triangles and centered
at the origin.

rad: radius of the sphere
meridian: number of slices
latitude: number of stacks.

*****************************************************/
std::vector<glm::vec3> getSphereVertices(float rad, int meridian, int latitude)
{
	// AJOUTER CODE ICI
	// EFFACER LE CONTENU DE CETTE FONCTION ET REMPLACEZ LE PAR DES VERTEX DEVANT FORMER UNE SPHERE DE RAYON "rad"

    std::vector<glm::vec3> vertices;
	glm::vec3 vertex;

	// First triangle
	vertex.x = 0.f; vertex.y = 0.f; vertex.z = 0.f;
	vertices.push_back(vertex);

	vertex.x = 0.f; vertex.y = rad; vertex.z = 0.f;
	vertices.push_back(vertex);

	vertex.x = rad; vertex.y = 0.f; vertex.z = 0.f;
	vertices.push_back(vertex);

	// second triangle
	vertex.x = 0.f; vertex.y = 0.f; vertex.z = 0.f;
	vertices.push_back(vertex);

	vertex.x = 0.f; vertex.y = 0.f; vertex.z = rad;
	vertices.push_back(vertex);

	vertex.x = 0.f; vertex.y = rad; vertex.z = 0.f;
	vertices.push_back(vertex);

	// third triangle
	vertex.x = rad; vertex.y = 0.f; vertex.z = 0.f;
	vertices.push_back(vertex);

	vertex.x = 0.f; vertex.y = rad; vertex.z = 0.f;
	vertices.push_back(vertex);

	vertex.x = 0.f; vertex.y = 0.f; vertex.z = rad;
	vertices.push_back(vertex);

	return vertices;
}


/*****************************************************
NAME: display

DESCRIPTION: displays the main window and all its object

*****************************************************/
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    setCameraMatrices();
	copyLightParametersOnGPU();

    drawPlane();
    if (displayRevolutionObject){
        drawRevolutionObject();
    }
	if (displayNormals && displayRevolutionObject) {
		drawNormals();
	}
	drawLight(0);  // white light
	drawLight(1);  // blue light

    glutSwapBuffers();
}

/*****************************************************
NAME: keyboard

DESCRIPTION: callback function for the keyboard

*****************************************************/
void keyboard(unsigned char key, int /* x */, int /* y */)
{
    GLint polyMode[2];
    switch (key)
    {
        // Light manipulation
    case '1':
    case '2':
        currentLight = &(lights[key - '1']);
        break;

    case '3':
        currentLight = NULL;
        break;
        
        // Object resolution
    case 'A':
        ++objectResolution;
		updatePlaneMesh();
		updateRevolutionObjectMesh();
		updateNormalLines();
        break;
    case 'a':
        --objectResolution;
		if (objectResolution <= 0) {
			objectResolution = 1;
		}
		updatePlaneMesh();
		updateRevolutionObjectMesh();
		updateNormalLines();

		break;

        // Camera parameters
    case 'b':
        gCam.ratio -= 0.05f;
        if (gCam.ratio<0.05f)
            gCam.ratio = 0.05f;
        printf("%f\n", gCam.ratio);
        break;

    case 'B':
        gCam.ratio += 0.05f;
        if (gCam.ratio>5.0f)
            gCam.ratio = 5.0f;
        printf("%f\n", gCam.ratio);
        break;

    case 'c':
        gCam.r -= 10.0f;
        if (gCam.r<1.0f)
            gCam.r = 1.0f;
        break;

    case 'C':
        gCam.r += 10;
        if (gCam.r>5000)
            gCam.r = 5000.0f;
        break;

    case 'e':
        gCam.fovy -= 1.0;
        if (gCam.fovy<1) gCam.fovy = 1.0;
        break;

    case 'E':
        gCam.fovy += 1.0;
        if (gCam.fovy>170) gCam.fovy = 170.0;
        break;


    case 'L': // Enable or disables the light
        isLightEnabled = !isLightEnabled;

    case 'n': // Enable/disable the normals
    case 'N':
        displayNormals = !displayNormals;
    break; 
	
	case 'o': // Enable/disable the revolution object
    case 'O':
        displayRevolutionObject = !displayRevolutionObject;
        break;

    case 27:// To exit
    case 'q':
        exit(0);
        break;

    case 'w':// wireframe
        glGetIntegerv(GL_POLYGON_MODE, polyMode);
        if (polyMode[1] == GL_LINE)
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        else
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        break;

        //Change shininess
    case 'z':
        materials[0].shininess -= 1.0;
        if (materials[0].shininess<1.0)
            materials[0].shininess = 1.0;
        break;
    case 'Z':
        materials[0].shininess += 1.0;
        if (materials[0].shininess>500.0)
            materials[0].shininess = 500.0;
        break;
    case 'x':
        materials[1].shininess -= 1.0;
        if (materials[1].shininess<1.0)
            materials[1].shininess = 1.0;
        break;
    case 'X':
        materials[1].shininess += 1.0;
        if (materials[1].shininess>500.0)
            materials[1].shininess = 500.0;
        break;


    default:
        printf("undefined key [%d]\n", (int)key);
        break;
    }

    glutPostRedisplay();
}

/*****************************************************
NAME: setCameraMatrices

DESCRIPTION: update the view and projection matrices
*****************************************************/
void setCameraMatrices()
{
    float z = gCam.r*cos(deg2rad(gCam.theta))*cos(deg2rad(gCam.phi));
    float x = gCam.r*sin(deg2rad(gCam.theta))*cos(deg2rad(gCam.phi));
    float y = gCam.r*sin(deg2rad(gCam.phi));

    viewMatrix = glm::lookAt(glm::vec3(x, y, z),       
                             glm::vec3(0.0, 0.0, 0.0), 
                             glm::vec3(0.0, 1.0, 0.0));

	projectionMatrix = glm::perspective(glm::radians(gCam.fovy), gCam.ratio, gCam.nearCP, gCam.farCP);  // Create our perspective projection matrix

}


/*****************************************************
NAME: mouseButton

DESCRIPTION: mouse button callback
*****************************************************/
void mouseButton(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN) {
        lastMouseEvt.button = button;
        lastMouseEvt.x = x;
        lastMouseEvt.y = y;
    }
    else if (state == GLUT_UP) {
        lastMouseEvt.button = -1;
        lastMouseEvt.x = -1;
        lastMouseEvt.y = -1;
	}
}

/*****************************************************
NAME: mouseMove

DESCRIPTION: mouse move callback.  x,y contains the position 
of the mouse in pixel units.
*****************************************************/
void mouseMove(int x, int y)
{
    int	dx = x - lastMouseEvt.x;
    int	dy = -y + lastMouseEvt.y;
    lastMouseEvt.x = x;
    lastMouseEvt.y = y;

    switch (lastMouseEvt.button)
    {
    case GLUT_LEFT_BUTTON:
    {
        /* Rotation */
        gCam.theta -= dx;
        gCam.phi -= dy;
        if (gCam.phi >  89) gCam.phi = 89;
        if (gCam.phi < -89) gCam.phi = -89;
        break;
    }
    case GLUT_MIDDLE_BUTTON:
    {
        /* Move current light */
        if (currentLight)
        {
            currentLight->position[0] += (viewMatrix[0][0] * dx + viewMatrix[0][1] * dy + viewMatrix[0][2] * 0 + viewMatrix[0][3] * 1) *gCam.r / 900;
            currentLight->position[1] += (viewMatrix[1][0] * dx + viewMatrix[1][1] * dy + viewMatrix[1][2] * 0 + viewMatrix[1][3] * 1) *gCam.r / 900;
            currentLight->position[2] += (viewMatrix[2][0] * dx + viewMatrix[2][1] * dy + viewMatrix[2][2] * 0 + viewMatrix[2][3] * 1) *gCam.r / 900;
        }
        break;
    }
    case GLUT_RIGHT_BUTTON:
    {
        /* Zoom in/out */
        gCam.r += dx - dy;
        if (gCam.r < 1)	gCam.r = 1;
        break;
    }
    default:
        return;
    }

    glutPostRedisplay();
}

/*****************************************************
NAME: init

DESCRIPTION: initialize everything
*****************************************************/
void init() {
    // Initialize GLEW
    glewExperimental = GL_TRUE;
    glewInit();

    // Enable depth test
    glDepthFunc(GL_LESS);
    glEnable(GL_DEPTH_TEST);

    // Black background
    glClearColor(0.3f, 0.3f, 0.3f, 1.0f);

    /*

    WARNING WARNING WARNING WARNING WARNING

    The shaders should be located in the working directory of the project for them to work.
    By default, Visual studio has it located where the vcxproj file (the project directory) is.
    You can check in the project properties (in the debugging section) what is the current
    working directory.

    WARNING WARNING WARNING WARNING WARNING

    */
	shader = new Shader("../../shader.vert", "../../shader.frag");
    // Objects
    initObjects();
    initMaterials();

    // Camera parameters
    gCam.theta = 0.0;
    gCam.phi = 89.0;
    gCam.r = 500.0;
    gCam.fovy = 45.0;
    gCam.ratio = 1.0;
    gCam.nearCP = 1.0;
    gCam.farCP = 3000.0;

	// Create the vertices of the 2 objects, the normals and the 2 sphere lights and copy it on the GPU
	updatePlaneMesh();
	updateRevolutionObjectMesh();
	updateNormalLines();
}

/*****************************************************
NAME: main

DESCRIPTION: create the window and setup the callback functions
	with the glut library.
*****************************************************/
int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    // Init the openGL window
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(500, 500);

    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitContextVersion(3, 3);

    glutCreateWindow("IMN428 -- TP3 ");

    init();

    // Callbacks
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMouseFunc(mouseButton);
    glutMotionFunc(mouseMove);
    glutMainLoop();

    return 0;
}